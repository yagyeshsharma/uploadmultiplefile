<?php
session_start();
$one= rand(1,60000);
$two= rand(2500,58000);
$unique=$one+$two;
$_SESSION['uniqueid'] = $unique;
$target_dir = "uploads/";
$directoryName = $target_dir.$unique;
if(!is_dir($directoryName)){
    //Directory does not exist, so lets create it.
    mkdir($directoryName, 0755);
}

$total = count($_FILES['RC']['name']);

// Loop through each file
for( $i=0 ; $i < $total ; $i++ ) {

  //Get the temp file path
  $tmpFilePath = $_FILES['RC']['tmp_name'][$i];

  //Make sure we have a file path
  if ($tmpFilePath != ""){
    //Setup our new file path
    $newFilePath = $directoryName ."/". $_FILES['RC']['name'][$i];

    //Upload the file into the temp dir
    if(move_uploaded_file($tmpFilePath, $newFilePath)) {
    	$con = mysqli_connect("localhost","root","","uploads");
    	$qry="insert into fileupload(file) Values('$newFilePath')";
    	$run=mysqli_query($con,$qry);
    	if($run)
    	{
    		echo  '<script>window.location="index.php";
    				alert("Uploaded Successfully!");
    		</script>';
    	}
      //Handle other code here

    }
  }
}


?>

<?php
/*
$one= rand(1,60000);
$two= rand(2500,58000);
echo "ONE : ".$one."<br>";
echo "TWO : ".$two."<br>";
echo "Unique ID".$unique=$one+$two;

$target_dir = "uploads/";
$directoryName = $target_dir.$unique;
 //echo $directoryName;
//Check if the directory already exists.
if(!is_dir($directoryName)){
    //Directory does not exist, so lets create it.
    mkdir($directoryName, 0755);
}
$target_file = $directoryName ."/". basename($_FILES["RC"]["name"]);
$uploadOk = 1;
$FileType = pathinfo($target_file,PATHINFO_EXTENSION);
// Check if image file is a actual image or fake image
   // $check = getimagesize($_FILES["RC"]["tmp_name"]);

if ($uploadOk == 0) {
    echo "Sorry, your file was not uploaded.";
// if everything is ok, try to upload file
} else {
    if (move_uploaded_file($_FILES["RC"]["tmp_name"], $target_file)) {
        echo "The file ". basename( $_FILES["RC"]["name"]). " has been uploaded.";
    } else {
        echo "Sorry, there was an error uploading your file.";
    }
}
$RC=$target_file;
*/
?>

<?php

//WORKING FINE AND ALSO GOING TO DATABASE
/*
$total = count($_FILES['RC']['name']);
// Loop through each file
for( $i=0 ; $i < $total ; $i++ ) {

  //Get the temp file path
  $tmpFilePath = $_FILES['RC']['tmp_name'][$i];

  //Make sure we have a file path
  if ($tmpFilePath != ""){
    //Setup our new file path
    $newFilePath = "testupload/" . $_FILES['RC']['name'][$i];

    //Upload the file into the temp dir
    if(move_uploaded_file($tmpFilePath, $newFilePath)) {
    	$con = mysqli_connect("localhost","root","","assignment");
    	$qry="insert into image_db(u_id,detail_id,file) Values('1','1','$newFilePath')";
    	$run=mysqli_query($con,$qry);
    	if($run)
    	{
    		echo  '<script>window.location="test.php";</script>';
    	}
      //Handle other code here

    }
  }
}
*/
?>
