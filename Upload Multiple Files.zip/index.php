<!DOCTYPE html>
<html>
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	<title>Upload Multiple Files By Yagyesh Sharma</title>
</head>
<body>
	<h1 style="text-align: center;">Upload Multiple Files </h1>
    <form enctype="multipart/form-data" method="POST" action="uploadfile.php">
	<table align="center">
    <tr>
      <td class="form-group">
      	<h3>Select Files</h3>
      </td>
    </tr>
    <tr>
      <td>
       <input type="file" name="RC[]" multiple required="required">
      </td>
      <td>
      	<button type="submit" class="btn btn-primary" >Submit</button>	
      </td>
    </tr>
  
  

</table>
</form>



	
	


  
</body>
</html>
